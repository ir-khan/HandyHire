export default {
    bgimage: require('../assets/images/background.png'),
    light: require('../assets/images/light.png'),
    pfp: require('../assets/images/pfp.jpeg'),
    avatar: require('../assets/images/person.png'),
};