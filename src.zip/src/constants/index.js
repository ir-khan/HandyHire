import ROUTES from './routes';
import IMGS from './imgs';
import COLORS from './colors';

export { ROUTES, IMGS, COLORS };