export default {
    primary: '#ba2f77',
    secondary: '#d969a3',
    white: '#fff',
    white2: '#fff0',
    inputBox: 'rgba(0, 0, 0, 0.1)',
    gray: '#a9a9a9'
};