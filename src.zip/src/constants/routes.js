export default {
    LOGIN: 'Login',
    SIGNUP: 'Signup',
    FORGOT_PASSWORD: 'Forgot Password',

    DASHBOARD: 'Dashboard',
    DRAWER: 'Drawer',

    HOME: 'Home',
    INBOX: 'Inbox',
    PROFILE: 'Profile',
    SERVICES: 'Services',
    NOTIFICATION : 'Notification'
};