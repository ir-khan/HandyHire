import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { LoginScreen, SignupScreen, ForgotPasswordScreen, NotificationScreen } from "../screens";
import { ROUTES } from "../constants";
import DrawerNavigator from "./DrawerNavigator";

const Stack = createNativeStackNavigator();

const AuthNavigator = () => {
    return (
        <Stack.Navigator initialRouteName={ROUTES.DRAWER} screenOptions={{ headerShown: false }}>
            <Stack.Screen name={ROUTES.LOGIN} component={LoginScreen} />
            <Stack.Screen name={ROUTES.SIGNUP} component={SignupScreen} />
            <Stack.Screen name={ROUTES.FORGOT_PASSWORD} component={ForgotPasswordScreen} />
            <Stack.Screen name={ROUTES.DRAWER} component={DrawerNavigator} />
            <Stack.Screen name={ROUTES.NOTIFICATION} component={NotificationScreen} />
        </Stack.Navigator>
    );
};

export default AuthNavigator;
