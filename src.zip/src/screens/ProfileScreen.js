import { StyleSheet, View, Text, TouchableOpacity, ScrollView, Image, Alert } from 'react-native';
import React, { useState } from 'react';
import { CustomDrawerButton } from '../components';
import { COLORS, IMGS } from '../constants';
import { selectImageFromGallery, takePhoto } from '../services';

const ProfileScreen = ({ navigation }) => {

  const [avatarSource, setAvatarSource] = useState(IMGS.avatar);

  const selectImage = () => {
    selectImageFromGallery((source) => {
      setAvatarSource({ uri: source.assets[0].uri });
    });
  };

  const takeNewPhoto = () => {
    takePhoto((source) => {
      setAvatarSource({ uri: source.assets[0].uri }); 
    });
  };


  const handleImagePress = () => {
    Alert.alert(
      'Select Image',
      'Choose the image source',
      [
        { text: 'Select from Gallery', onPress: selectImage,  },
        { text: 'Take Photo', onPress: takeNewPhoto },
      ],
      { cancelable: false }
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.appBar}>
        <CustomDrawerButton navigation={navigation} />
        <Text style={styles.appBarText}>Profile</Text>
        <View style={{ width: 35 }}></View>
      </View>
      <ScrollView style={styles.body}>
        <View>
          <TouchableOpacity onPress={handleImagePress}>
            <Image source={avatarSource} style={styles.avatar} />
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
},
appBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    position: 'static',
    height: '13%',
    backgroundColor: COLORS.white,
    paddingBottom: 13,
    paddingHorizontal: 5,
},
appBarText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: COLORS.primary,
},
  body: {
    flex: 1,
    backgroundColor: 'white',
    margin: 10,
    elevation: 5,
    borderRadius: 10,
    shadowColor: 'grey',
    shadowOpacity: 1,
  },
  avatar: {
    width: 200,
    height: 200,
    borderRadius: 100,
    alignSelf: 'center',
    marginVertical: 30,
  },
});