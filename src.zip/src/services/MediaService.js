import { RequestCamera, RequestMediaLibrary } from "../components";
import * as ImagePicker from 'expo-image-picker';

const selectImageFromGallery = async (callback) => {
    const status = await RequestMediaLibrary();
    if (status === 'granted') {
        let result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.All,
            allowsEditing: true,
            aspect: [1, 1],
            quality: 1,
        });
        callback(result);
    }
};

const takePhoto = async (callback) => {
    const status = await RequestCamera();
    if (status === 'granted') {
        let result = await ImagePicker.launchCameraAsync({
            allowsEditing: true,
            aspect: [1, 1],
            quality: 1,
        });;
        callback(result);
    }
};

export { selectImageFromGallery, takePhoto };